mvn package will get you grants.war
deployment : 
tomcat --> webapps --> grants.war
Config : tomcat-user.xml

sdfsdf


